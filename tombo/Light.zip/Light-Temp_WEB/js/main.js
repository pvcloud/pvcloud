/**
 * Function to be called by the system when everything is ready @ browser. 
 */
$(document).ready(function () {
    configureEvents();
});

/**
 * Configures behavior of each actionable control in the page.
 * @returns {undefined}
 */
function configureEvents() {
    $("#btnBegin").click(function () {
        $("#btnBegin").hide();
        $("#btnStop").show();
        stopFlag = false;
        beginCapture();
    }).removeAttr("disabled").text("BEGIN");

    $("#btnStop").click(function () {
        stopFlag = true;
        $("#btnBegin").show();
        $("#btnStop").hide();
        $("#imgClock").hide();
    });
}

/**
 * Flag used to control the recurrent retrieval of information from pvCloud
 * @type Boolean
 */
var stopFlag = false;

/**
 * Initiates and performs the recurrent capture of data from pvCloud
 * @returns {undefined}
 */
function beginCapture() {
    $("#imgClock").hide();
    if (!stopFlag) { /** /si stopflag es false, o sea si el boton no se ha presionado */
        var time = $("#txtCheckTime").val(); /** /txtCheckTime es el tiempo que uno le da para calcular*/

          $("#val_L").html("...");
        $("#created_datetime").html("loading...");

        GetPVCLOUDValue(function (response) { /** /Obtiene el valor de pvCloud, ejecuta hasta que GetPVCLOUDValue tenga un valor */
            processResponse(response); /** /Data = response */
            $("#imgClock").show();
            setTimeout(beginCapture, time * 1000); /** /Se setea solo para volver a contar cada tiempo segun el #txtCheckTime */
        });
    }
}

/**
 * Processes a response value coming from retrieving data from pvCloud
 * @param {object} response
 * @returns {undefined}
 */
function processResponse(response) {
    var value = JSON.parse(response.vse_value); /** /  Pasa de tipo JSON (String) a un objeto Java. {T:20,H:60} --> value.H value.T   */
    var created_datetime = response.created_datetime; /** /    created_datetime = atributo de pvCloud q se da como un string */
    if (value) {
        /** /    Pasando los valores a la pagina */
        $("#val_L").html(value.L);


        var now = new Date();
        var createdDateObj = new Date(created_datetime); /** /  pasa  created_datetime de string a date */
        createdDateObj.setHours(createdDateObj.getHours() + 1); /** / Hora de creacion del registro */
        console.log(now);

        console.log(createdDateObj);
        $("#created_datetime").html(createdDateObj); /** / Asigna a #created_datetime el valor html de createdDateObj */

        var diffsec = (now - createdDateObj) / 1000;

        if (diffsec > 60) {
            $("#created_datetime").css("color", "red"); /** / No ha vuelto a recibir datos hace 60 seg, se pone en rojo */
        } else {
            $("#created_datetime").css("color", "green");
        }

        processWarnings();
        console.log(diffsec);

    }
    console.log(value);
}

var messageSent = false;
var messageSentEmail = "";
function processWarnings() {
    var ligWarningValue = 1 * $("#txtWarning_L_Trigger").val();
    var ligAlertValue = 1 * $("#txtAlert_L_Trigger").val();
    var currentLig = 1 * $("#val_L").text();

    console.log({currentLig: currentLig}); /** /    Con F12, Se ven en console para hacer debugging del sistema */
    console.log({ligWarning: ligWarningValue, ligAlert: ligAlertValue});

    var message = "";
   
    if (currentLig <= ligAlertValue) {
        $("#iconHumidity").css("color", "red");
        if (message !== "")
            message += " | ";
        message += "Light ALERT (" + currentLig + " <= " + ligAlertValue + ") ";
    } else if (currentLig <= ligWarningValue) {
        $("#iconHumidity").css("color", "orange");
    } else {
        $("#iconHumidity").css("color", "green");
    }

    var email = $("#txtAlertEmail").val();

    if (message !== "" && messageSentEmail !== email && email !== "") {
        var url = "sendAlert.php?email=" + email + "&key=1&message=" + encodeURIComponent(message);
        console.log("SENDING EMAIL...");
        console.log(url);
        $.ajax({
            url: url,
            success: function (response) {
                messageSentEmail = email;
                console.log("EMAIL SENT");
            }
        });
    }

}

/**
 * Actually pefroms a Web Service Call to pvCloud to retrieve last value registered for the app.
 * @param {type} callback
 * @returns {undefined}
 */
function GetPVCLOUDValue(callback) { /** /   Llamada en el browser, todo en el main.js */
    var url = BuildPVCloudURL_GetLastValue();

    $.ajax(url, {/** /Utiliza el url y hace que el browser llame a PVCloud, asincronica, no se detiene ahi, sigue llamando*/
        success: function (data) { /** /Data son los datos de PVCloud */
            callback(data); /** / Cuando tiene el dato, hace el callback y devuelve la info GetPVCLOUDValue, si no hay valores data es null  */
        },
        error: function (error) { /** / Error de comunicacion  */
            console.log(error);
            return null;
        }

    });

}

/**
 * Crafts a URL with the necessary parameters for getting last value from pvCloud
 * @returns {String}
 */
function BuildPVCloudURL_GetLastValue() {
    var api_key = "f3dbbbaf02c968691eb0c5a5f1907a20d1462634";
    var device_id = 11; /** /    ID del Galileo */
    var account_id = 7;

    var url = "https://costaricamakers.com/pvcloud_backend/vse_get_value_last.php?account_id=" + account_id;
    url += "&device_id=" + device_id;
    url += "&api_key=" + api_key;
    url += "&optional_label=LightSensor_READING";

    return url;
}
